<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "gestao_utilizadores";

$conn = new mysqli($servidor, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'error' => 'Connection failed']));
}

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $product_id = $_POST['product_id'] ?? 0;
    $quantity = $_POST['quantity'] ?? 1;

    switch ($action) {
        case 'add':
            // Add/update product in cart
            if (!isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id] = 0;
            }
            $_SESSION['cart'][$product_id] += $quantity;
            echo json_encode(['success' => true]);
            break;

        case 'update':
            // Update quantity
            if ($quantity > 0) {
                $_SESSION['cart'][$product_id] = $quantity;
            } else {
                unset($_SESSION['cart'][$product_id]);
            }
            echo json_encode(['success' => true]);
            break;

        case 'remove':
            // Remove product from cart
            unset($_SESSION['cart'][$product_id]);
            echo json_encode(['success' => true]);
            break;

        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    exit;
}

// Handle GET requests (display cart)
$cart_items = [];
if (!empty($_SESSION['cart'])) {
    $product_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', array_map('intval', $product_ids));
    
    $sql = "SELECT id, nome, preco, imagem FROM produtos WHERE id IN ($ids_string)";
    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $row['quantity'] = $_SESSION['cart'][$row['id']];
        $row['total'] = $row['preco'] * $row['quantity'];
        $cart_items[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras</title>
    <link rel="stylesheet" href="styles/all.css">
    <link rel="stylesheet" href="styles/header.css">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" />
    <style>
        .cart-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .cart-item {
            display: flex;
            align-items: center;
            padding: 1rem;
            border-bottom: 1px solid #eee;
        }

        .cart-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            margin-right: 1rem;
            border-radius: 4px;
        }

        .cart-item-details {
            flex-grow: 1;
        }

        .quantity-controls {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .quantity-controls button {
            padding: 5px 10px;
            border: none;
            background: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        .cart-summary {
            margin-top: 2rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 4px;
        }

        .empty-cart {
            text-align: center;
            padding: 2rem;
            color: #666;
        }
    </style>
</head>
<body>
<nav class="navbar">
        <h1>Berto</h1>
        <ul class="navbar-list">
            <li><a href="#">inicio</a></li>
            <li><a href="produtos.php">produtos</a></li>
            <li><a href="#">sobre</a></li>
        </ul>

        <div class="profile-dropdown">
            <div onclick="toggle()" class="profile-dropdown-btn">
                <div class="profile-img">
                    <i class="fa-solid fa-circle"></i>
                </div>

                <span>
                    <?php echo htmlspecialchars($nome_usuario); ?>
                    <i class="fa-solid fa-angle-down"></i>
                </span>
            </div>

            <ul class="profile-dropdown-list">
                <li class="profile-dropdown-list-item">
                    <a href="utilizador/profile/index.php">
                        <i class="fa-regular fa-user"></i>
                        Edit Profile
                    </a>
                </li>

                <li class="profile-dropdown-list-item">
                    <a href="#">
                        <i class="fa-solid fa-sliders"></i>
                        Settings
                    </a>
                </li>

                <li class="profile-dropdown-list-item">
                    <a href="utilizador/gestao_produtos.php">
                        <i class="fa-regular fa-circle-question"></i>
                        Gestão de produtos
                    </a>
                </li>
                <hr />

                <li class="profile-dropdown-list-item">
                    <form id="logout-form" action="utilizador/logout.php" method="POST">
                        <input type="hidden" name="botaoLogout">
                        <a href="#" onclick="document.getElementById('logout-form').submit();">
                            <i class="fa-solid fa-arrow-right-from-bracket"></i>
                            Log out
                        </a>
                    </form>
                </li>
            </ul>
        </div>
    </nav>
    
    <div class="cart-container">
        <h2>Carrinho de Compras</h2>
        
        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <p>Seu carrinho está vazio</p>
                <a href="produtos.php" class="btn">Continuar Comprando</a>
            </div>
        <?php else: ?>
            <?php foreach ($cart_items as $item): ?>
                <div class="cart-item" data-id="<?php echo $item['id']; ?>">
                    <img src="utilizador/uploads<?php echo $item['imagem']; ?>" alt="<?php echo $item['nome']; ?>">
                    <div class="cart-item-details">
                        <h3><?php echo $item['nome']; ?></h3>
                        <p>Preço: €<?php echo number_format($item['preco'], 2); ?></p>
                        <div class="quantity-controls">
                            <button onclick="updateQuantity(<?php echo $item['id']; ?>, -1)">-</button>
                            <span class="quantity"><?php echo $item['quantity']; ?></span>
                            <button onclick="updateQuantity(<?php echo $item['id']; ?>, 1)">+</button>
                            <button onclick="removeItem(<?php echo $item['id']; ?>)">Remover</button>
                        </div>
                        <p>Total: €<?php echo number_format($item['total'], 2); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="cart-summary">
                <h3>Resumo do Pedido</h3>
                <p>Total: €<?php echo number_format(array_sum(array_column($cart_items, 'total')), 2); ?></p>
                <button onclick="checkout()">Finalizar Compra</button>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function updateQuantity(productId, change) {
            const item = document.querySelector(`.cart-item[data-id="${productId}"]`);
            const quantitySpan = item.querySelector('.quantity');
            let newQuantity = parseInt(quantitySpan.textContent) + change;
            
            if (newQuantity < 1) newQuantity = 1;
            
            fetch('cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=update&product_id=${productId}&quantity=${newQuantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function removeItem(productId) {
            if (confirm('Tem certeza que deseja remover este item?')) {
                fetch('cart.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=remove&product_id=${productId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    }
                });
            }
        }

        function checkout() {
            alert('Implementar checkout aqui!');
            // Implement checkout logic
        }
    </script>
</body>
</html>
